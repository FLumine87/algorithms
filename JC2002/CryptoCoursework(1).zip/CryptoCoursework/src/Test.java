import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Author: Marco A. Palomino
 * Course: JC2002
 * Date: 3 October 2025
 * <p>
 * Description: A number of methods to test the implementation of
 *              the Caesar Cipher.
 */
public class Test {

    /**
     *
     * @param message The string to be encrypted.
     */
    public static void testCaesarString(String message) {
        // First, create a new CaesarCipher object with key=23.
        CaesarCipher cc = ...

        // Encrypt the given String!
        ...

        // Print out the encrypted String on the screen!
        ...

    } // End of testCaesarString(message)


    /**
     * Reads a file encrypted with a single key and decrypt its contents,
     * using the CaesarBreaker decrypt() method. After that, the method
     * should print the encrypted message on the screen.
     *
     * @param fileName The name of the file to be encrypted.
     * @throws Exception
     */
    public void testCaesarDecryptFile(String fileName)
            throws Exception {

        // Read a text file and keep the contents in a String called
        // message!
        String message = ...

        // Create a CaesarBreaker object.
        CaesarBreaker cb = ...

        // Decrypt the message!
        String decrypted = ...

        // Print out the decrypted file on the screen!
        ...
    } // End of testCaesarDecryptFile(fileName)


    /**
     * This method should read a file and encrypt the complete file using
     * the Caesar Cipher algorithm. After that, the method should print the
     * encrypted message on the screen.
     *
     * @param fileName The name of the file to be encrypted.
     * @throws Exception
     */
    public static void testCaesarFile(String fileName)
            throws Exception {
        // First, create a new CaesarCipher object with key=5.
        ...

        // Read a text file and keep the contents in a String called
        // message!
        ...

        // Encrypt the contents of the file!
        ...

        // Print out the encrypted file on the screen!
        ...
    } // End of testCaesarFile(fileName)


    /**
     * This method should receive a message as a String parameter, create
     * a new CaesarCipherMultipleKeys object with two keys (23 and 17),
     * and encrypt the message. At the end, the method should print out
     * the result on the screen.
     *
     * @param message The string to be encrypted.
     */
    public static void testCaesarMultipleKeysString(String message) {
        // First, choose your keys.
        int[] keys = ...

        // Then, create a new CaesarCipherMultipleKeys object with such keys.
        CaesarCipherMultipleKeys ccmk = ...

        // Encrypt the given String!
        ...

        // Print out the encrypted String!
        ...

    } // End of testCaesarMultipleKeysString(message)
} // End of class Test
