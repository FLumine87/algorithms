/**
 *      Author: Marco A. Palomino
 *      Course: JC2002
 *        Date: 7 October 2025
 *
 * Description: A class to implement the Caesar Cipher algorithm. It
 *              will require some enhancements to work with all letters
 *              (both uppercase and lowercase) and to make it harder to
 *              decrypt.
 */
public class CaesarCipher {
    /**
     * All the characters in the English alphabet (must be 26).
     */
    private String alphabet;

    /**
     * The key for this cipher.
     */
    private int theKey;

    /**
     * The English alphabet after "shifting" it by the given key.
     */
    private String shiftedAlphabet;

    /**
     * Constructor
     *
     * @param key The key for the encryption algorithm.
     */
    public CaesarCipher(int key) {
        // Assign the value of the key for this cipher to the instance
        // variable theKey.
        ...

        // Whenever we create a new CaesarCipher object, we will also
        // generate two String objects: one containing the standard
        // alphabet and another containing the shifted alphabet. This
        // ensures that we can quickly map each letter in the original
        // message to its encrypted counterpart. You have been given
        // the standard alphabet, but you have to create the shifted
        // alphabet. Recall that the shift depends on the key!
        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        shiftedAlphabet = ...

        // In Task 4, you will need to make changes to ensure that the
        // encryption works with all letters (both uppercase and
        // lowercase). But do not change anything here until you reach
        // Task 4.
        ...

    } // End of CaesarCipher(int key)

    /**
     * This method returns a string (message) which has been encrypted
     * using the Caesar Cipher Algorithm.
     *
     * @param message The string to be encrypted.
     * @return The encrypted message.
     */
    public String encrypt(String message) {
        // Make a StringBuilder to build the encrypted message.
        StringBuilder encrypted = ...

        // Starting from 0, and all the way to the length of the
        // message, encrypt one by one each character.
        for (int i = 0; i < message.length(); i++) {

            // Consider the i-th character of the message (call it
            // currentChar)
            char currentChar ...

            // First, check if the following character in the message
            // is an alphabetic character. All other characters
            // (spaces, punctuation, and numbers) will remain the same.
            ...

            // If it is not an alphabetic character, add the character
            // (as it is) to the encrypted message.
            ...
        } // End of for (int i = 0; i < message.length(); i++)

        // Your answer must be the String inside the StringBuilder
        // variable called 'encrypted'.
        return ...
    } // End of encrypt(message)

} // End of CaesarCipher